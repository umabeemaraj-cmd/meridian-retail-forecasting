#!/usr/bin/env python3
"""Meridian launcher.

  python run.py                 build (if needed) and open the dashboard
  python run.py --rebuild       force a full re-run of the pipeline
  python run.py --data FILE     use another csv/xlsx (same columns)
  python run.py --no-serve      only build, do not start the web server
"""
import argparse
import http.server
import socketserver
import sys
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rebuild", action="store_true")
    ap.add_argument("--data")
    ap.add_argument("--no-serve", action="store_true")
    ap.add_argument("--port", type=int, default=8765)
    a = ap.parse_args()

    need = a.rebuild or a.data or not (ROOT / "web" / "data.js").exists()
    if need:
        try:
            from src import build
        except ImportError as e:
            sys.exit(f"Missing dependency ({e}). Run:  pip install -r requirements.txt")
        build.main(a.data)
    else:
        print("web/data.js already built (use --rebuild to regenerate).")
    if a.no_serve:
        return

    class Quiet(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *args, **kw):
            super().__init__(*args, directory=str(ROOT / "web"), **kw)

        def log_message(self, *args):
            pass

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("127.0.0.1", a.port), Quiet) as srv:
        url = f"http://127.0.0.1:{a.port}/index.html"
        print(f"\nMeridian is live at {url}   (Ctrl+C to stop)")
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            print("\nbye")


if __name__ == "__main__":
    main()
