'use strict';
/* Meridian dashboard — zero dependencies, hand-built SVG charts. Data comes from data.js (window.MERIDIAN). */
(function () {
const D = window.MERIDIAN, M = D.meta, NS = 'http://www.w3.org/2000/svg';
const $ = s => document.querySelector(s);
const MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const PAL = ['#9f1239', '#d6a0ae', '#a18cff', '#ff6b6b', '#7bd88f'];
const CL = ['#9f1239', '#d6a0ae', '#a18cff', '#ff6b6b'];

/* ---------- formatting ---------- */
const cr = v => '₹' + (v / 1e7).toLocaleString('en-IN', { maximumFractionDigits: 0 }) + ' Cr';
const cr1 = v => '₹' + (v / 1e7).toLocaleString('en-IN', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + ' Cr';
const cr2 = v => '₹' + (v / 1e7).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Cr';
const num = v => Math.round(v).toLocaleString('en-IN');
const pct = (v, d = 1) => (v >= 0 ? '+' : '') + (v * 100).toFixed(d) + '%';
const pc = (v, d = 1) => (v * 100).toFixed(d) + '%';
const lakh = v => '₹' + (v / 1e5).toFixed(2) + ' L';
const pv = p => p < 0.001 ? 'p<0.001' : 'p=' + p.toFixed(2);
const dt = ms => { const d = new Date(ms); return d.getUTCDate() + ' ' + MON[d.getUTCMonth()] + ' ' + d.getUTCFullYear(); };

/* ---------- dom helpers ---------- */
function el(tag, attrs, parent, text) {
  const e = document.createElementNS(NS, tag);
  for (const k in attrs || {}) e.setAttribute(k, attrs[k]);
  if (text != null) e.textContent = text;
  if (parent) parent.appendChild(e);
  return e;
}
const tipEl = $('#tip');
function showTip(ev, html) {
  tipEl.innerHTML = html; tipEl.style.opacity = 1;
  const w = tipEl.offsetWidth || 200; let x = ev.clientX + 14;
  if (x + w > window.innerWidth - 10) x = ev.clientX - w - 14;
  tipEl.style.left = x + 'px'; tipEl.style.top = (ev.clientY + 14) + 'px';
}
const hideTip = () => { tipEl.style.opacity = 0; };
function niceTicks(lo, hi, n) {
  const raw = (hi - lo) / n, p = Math.pow(10, Math.floor(Math.log10(raw || 1))), f = raw / p;
  const step = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p, out = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) out.push(v);
  return out;
}
function monthTicks(t, every) {
  const out = []; let last = -1;
  for (let i = 0; i < t.length; i++) {
    const d = new Date(t[i]), k = d.getUTCFullYear() * 12 + d.getUTCMonth();
    if (k !== last && d.getUTCMonth() % every === 0) out.push({ x: t[i], l: MON[d.getUTCMonth()] + (d.getUTCMonth() === 0 ? " '" + String(d.getUTCFullYear()).slice(2) : '') });
    last = k;
  }
  return out;
}

/* ---------- time / filter state ---------- */
const N = M.dates.length;
const T = M.dates.map(d => Date.parse(d));
const DY = M.dates.map(d => +d.slice(0, 4)), DM = M.dates.map(d => +d.slice(5, 7));
const DOW = T.map(t => (new Date(t).getUTCDay() + 6) % 7);
const SR = M.stores.map(s => s.region);
const MY = M.months.map(m => +m.slice(0, 4)), MMn = M.months.map(m => +m.slice(5, 7));
const SC = M.subs.map(s => s.cat);
const S = { year: 0, region: '', cat: -1 };
const range = () => { if (!S.year) return [0, N - 1]; let a = DY.indexOf(S.year), b = DY.lastIndexOf(S.year); return [a, b]; };
function dailySeries(metric, ignoreYear) {
  const c = D.daily, out = new Array(N).fill(0), src = c[metric];
  for (let i = 0; i < c.d.length; i++) {
    if ((ignoreYear || !S.year || DY[c.d[i]] === S.year) && (!S.region || SR[c.s[i]] === S.region) && (S.cat < 0 || c.c[i] === S.cat)) out[c.d[i]] += src[i];
  }
  return out;
}
function bucket(vals, mode, a, b) {
  const x = [], y = [];
  if (mode === 'day') { for (let i = a; i <= b; i++) { x.push(T[i]); y.push(vals[i]); } return { x, y }; }
  const key = i => mode === 'week' ? Math.floor((T[i] / 864e5 + 3) / 7) : DY[i] * 12 + DM[i];
  let cur = null, sum = 0, cnt = 0, st = 0;
  const flush = () => {
    if (cur === null) return;
    const full = mode === 'week' ? cnt === 7 : cnt === new Date(Date.UTC(DY[st], DM[st], 0)).getUTCDate();
    if (full) { x.push(T[st]); y.push(sum); }
  };
  for (let i = a; i <= b; i++) {
    const k = key(i);
    if (k !== cur) { flush(); cur = k; sum = 0; cnt = 0; st = i; }
    sum += vals[i]; cnt++;
  }
  flush();
  return { x, y };
}

/* ---------- chart primitives ---------- */
function tsChart(host, o) {
  host.innerHTML = '';
  const W = host.clientWidth || 800, H = o.height || 280, m = { l: o.ml || 58, r: 16, t: 12, b: 26 };
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H }, host);
  const xs = o.x, x0 = o.xmin != null ? o.xmin : xs[0], x1 = o.xmax != null ? o.xmax : xs[xs.length - 1];
  let lo = Infinity, hi = -Infinity;
  o.layers.forEach(l => [l.y, l.y0].forEach(a => a && a.forEach(v => { if (v != null && isFinite(v)) { lo = Math.min(lo, v); hi = Math.max(hi, v); } })));
  if (!isFinite(lo)) { lo = 0; hi = 1; }
  const pad = (hi - lo) * 0.08 || 1;
  lo = o.ymin != null ? o.ymin : (o.zero ? 0 : lo - pad); hi = o.ymax != null ? o.ymax : hi + pad;
  const sx = x => m.l + (x - x0) / ((x1 - x0) || 1) * (W - m.l - m.r);
  const sy = v => H - m.b - (v - lo) / ((hi - lo) || 1) * (H - m.t - m.b);
  niceTicks(lo, hi, 5).forEach(t => {
    el('line', { x1: m.l, x2: W - m.r, y1: sy(t), y2: sy(t), class: 'grid' }, svg);
    el('text', { x: m.l - 8, y: sy(t) + 4, class: 'ax', 'text-anchor': 'end' }, svg, o.fmtY(t));
  });
  (o.xticks || []).forEach(t => el('text', { x: sx(t.x), y: H - 8, class: 'ax', 'text-anchor': 'middle' }, svg, t.l));
  const path = (ys) => {
    let d = '', pen = false;
    for (let i = 0; i < xs.length; i++) {
      const v = ys[i];
      if (v == null || !isFinite(v)) { pen = false; continue; }
      d += (pen ? 'L' : 'M') + sx(xs[i]).toFixed(1) + ' ' + sy(v).toFixed(1); pen = true;
    }
    return d;
  };
  const span = ys => { let a = -1, b = -1; ys.forEach((v, i) => { if (v != null) { if (a < 0) a = i; b = i; } }); return [a, b]; };
  o.layers.forEach(l => {
    if (l.type === 'band') {
      const [a, b] = span(l.y); if (a < 0) return;
      let d = 'M';
      for (let i = a; i <= b; i++) d += (i > a ? 'L' : '') + sx(xs[i]).toFixed(1) + ' ' + sy(l.y[i]).toFixed(1);
      for (let i = b; i >= a; i--) d += 'L' + sx(xs[i]).toFixed(1) + ' ' + sy(l.y0[i]).toFixed(1);
      el('path', { d: d + 'Z', fill: l.color, opacity: l.opacity || .2 }, svg);
    } else if (l.type === 'area') {
      const [a, b] = span(l.y); if (a < 0) return;
      const id = 'g' + Math.random().toString(36).slice(2, 7);
      const defs = el('defs', {}, svg), g = el('linearGradient', { id, x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
      el('stop', { offset: '0%', 'stop-color': l.color, 'stop-opacity': .35 }, g); el('stop', { offset: '100%', 'stop-color': l.color, 'stop-opacity': 0 }, g);
      el('path', { d: path(l.y) + `L${sx(xs[b]).toFixed(1)} ${sy(lo)}L${sx(xs[a]).toFixed(1)} ${sy(lo)}Z`, fill: `url(#${id})` }, svg);
      el('path', { d: path(l.y), fill: 'none', stroke: l.color, 'stroke-width': l.width || 1.6 }, svg);
    } else {
      el('path', { d: path(l.y), fill: 'none', stroke: l.color, 'stroke-width': l.width || 1.6, 'stroke-dasharray': l.dash || '', opacity: l.opacity || 1, 'stroke-linejoin': 'round' }, svg);
    }
  });
  if (o.split != null) {
    el('line', { x1: sx(o.split), x2: sx(o.split), y1: m.t, y2: H - m.b, stroke: '#5d6578', 'stroke-dasharray': '3 4' }, svg);
    el('text', { x: sx(o.split) + 6, y: m.t + 10, class: 'ax' }, svg, o.splitLabel || '');
  }
  const cross = el('line', { y1: m.t, y2: H - m.b, stroke: '#ebe8e1', opacity: 0, 'stroke-width': 1 }, svg);
  const ov = el('rect', { x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: 'transparent' }, svg);
  ov.addEventListener('mousemove', ev => {
    const r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) * (W / (r.width || W));
    const xv = x0 + (px - m.l) / (W - m.l - m.r) * (x1 - x0);
    let a = 0, b = xs.length - 1;
    while (b - a > 1) { const c = (a + b) >> 1; if (xs[c] < xv) a = c; else b = c; }
    const i = Math.abs(xs[a] - xv) < Math.abs(xs[b] - xv) ? a : b;
    cross.setAttribute('x1', sx(xs[i])); cross.setAttribute('x2', sx(xs[i])); cross.setAttribute('opacity', .35);
    let html = `<b>${o.xfmt ? o.xfmt(xs[i]) : xs[i]}</b>`;
    o.layers.forEach(l => { if (l.name && l.y[i] != null) html += `<br><span style="color:${l.color}">●</span> ${l.name}: ${(l.fmt || o.fmtY)(l.y[i])}`; });
    showTip(ev, html);
  });
  ov.addEventListener('mouseleave', () => { hideTip(); cross.setAttribute('opacity', 0); });
}

function barChart(host, items, o) {
  host.innerHTML = '';
  const W = host.clientWidth || 400, H = o.height || 180, m = { l: 44, r: 8, t: 14, b: 24 };
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H }, host);
  const base = o.base || 0;
  let lo = o.min != null ? o.min : Math.min(base, ...items.map(i => i.v)), hi = o.max != null ? o.max : Math.max(base, ...items.map(i => i.v));
  const pad = (hi - lo) * .1 || 1; if (o.min == null) lo -= base === 0 ? 0 : pad; if (o.max == null) hi += pad;
  const sy = v => H - m.b - (v - lo) / ((hi - lo) || 1) * (H - m.t - m.b);
  niceTicks(lo, hi, 4).forEach(t => {
    el('line', { x1: m.l, x2: W - m.r, y1: sy(t), y2: sy(t), class: 'grid' }, svg);
    el('text', { x: m.l - 6, y: sy(t) + 4, class: 'ax', 'text-anchor': 'end' }, svg, o.fmt(t));
  });
  const bw = (W - m.l - m.r) / items.length;
  items.forEach((it, i) => {
    const x = m.l + i * bw + bw * .18, w = bw * .64, y1 = sy(Math.max(it.v, base)), y2 = sy(Math.min(it.v, base));
    const r = el('rect', { x, y: y1, width: w, height: Math.max(1, y2 - y1), rx: 3, fill: it.c || '#d6a0ae', opacity: .9 }, svg);
    r.addEventListener('mousemove', ev => showTip(ev, `<b>${it.l}</b><br>${(o.tfmt || o.fmt)(it.v)}`)); r.addEventListener('mouseleave', hideTip);
    el('text', { x: x + w / 2, y: H - 8, class: 'ax', 'text-anchor': 'middle' }, svg, it.l);
  });
  if (base) el('line', { x1: m.l, x2: W - m.r, y1: sy(base), y2: sy(base), stroke: '#8d95a8', 'stroke-dasharray': '4 4' }, svg);
}

function arc(cx, cy, r0, r1, a0, a1) {
  if (a1 - a0 >= Math.PI * 2 - 1e-4) a1 = a0 + Math.PI * 2 - 1e-4;
  const p = (r, a) => [(cx + r * Math.sin(a)).toFixed(2), (cy - r * Math.cos(a)).toFixed(2)], lg = a1 - a0 > Math.PI ? 1 : 0;
  const A = p(r1, a0), B = p(r1, a1), C = p(r0, a1), E = p(r0, a0);
  return `M${A[0]} ${A[1]}A${r1} ${r1} 0 ${lg} 1 ${B[0]} ${B[1]}L${C[0]} ${C[1]}A${r0} ${r0} 0 ${lg} 0 ${E[0]} ${E[1]}Z`;
}

/* ======================= 01 BRIEFING ======================= */
function yoy(metric) {
  const s = dailySeries(metric, true), a = { 2023: 0, 2024: 0 };
  for (let i = 0; i < N; i++) a[DY[i]] += s[i];
  return a;
}
function spark(vals, color) {
  const W = 92, H = 30, lo = Math.min(...vals), hi = Math.max(...vals), svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H });
  let d = ''; vals.forEach((v, i) => { d += (i ? 'L' : 'M') + (i / (vals.length - 1) * W).toFixed(1) + ' ' + (H - 3 - (v - lo) / ((hi - lo) || 1) * (H - 6)).toFixed(1); });
  el('path', { d, fill: 'none', stroke: color, 'stroke-width': 1.6, 'stroke-linecap': 'round' }, svg);
  return svg;
}
function renderKPIs() {
  const [a, b] = range(), host = $('#kpis'); host.innerHTML = '';
  const rev = dailySeries('rev'), n = dailySeries('n'), un = dailySeries('units'), sl = dailySeries('sales');
  const sum = arr => { let s = 0; for (let i = a; i <= b; i++) s += arr[i]; return s; };
  const R = sum(rev), Nn = sum(n), U = sum(un), G = sum(sl), days = b - a + 1;
  const yr = yoy('rev'), yn = yoy('n'), g = yr[2023] ? yr[2024] / yr[2023] - 1 : 0, gn = yn[2023] ? yn[2024] / yn[2023] - 1 : 0;
  const mo = bucket(rev, 'month', a, b).y;
  const cards = [
    { l: 'Net revenue', v: cr(R), d: S.year ? 'selected year' : `2024 vs 2023 ${pct(g)}`, cls: g < -.005 ? 'dn' : g > .005 ? 'up' : 'fl', sp: mo, c: '#9f1239' },
    { l: 'Transactions', v: num(Nn), d: S.year ? 'selected year' : `2024 vs 2023 ${pct(gn)}`, cls: gn < -.005 ? 'dn' : gn > .005 ? 'up' : 'fl', sp: bucket(n, 'month', a, b).y, c: '#d6a0ae' },
    { l: 'Average ticket', v: Nn ? lakh(R / Nn) : '–', d: Nn ? `${(U / Nn).toFixed(1)} units per sale` : '', cls: 'fl', sp: null },
    { l: 'Revenue per day', v: cr2(R / days), d: `${days} days in scope`, cls: 'fl', sp: null },
    { l: 'Discount given away', v: cr(G - R), d: `${pc(G ? (G - R) / G : 0)} of gross sales`, cls: 'dn', sp: null },
    { l: 'Units sold', v: num(U), d: 'across all subcategories', cls: 'fl', sp: bucket(un, 'month', a, b).y, c: '#a18cff' }];
  cards.forEach(k => {
    const d = document.createElement('div'); d.className = 'card kpi';
    d.innerHTML = `<div class="l">${k.l}</div><div class="v">${k.v}</div><div class="d ${k.cls}">${k.d}</div>`;
    if (k.sp) d.appendChild(spark(k.sp, k.c)); host.appendChild(d);
  });
}
function renderBrief() {
  const k = D.kpi, tot = D.forecast.TOTAL;
  $('#hero').innerHTML = `${cr(k.revenue)} in 24 months, eight stores — and <em>one honest forecast</em>.`;
  $('#heroDeck').textContent = `${num(M.rows)} transactions from ${dt(T[0])} to ${dt(T[N - 1])}. Meridian cleans the data, tests whether the future is actually predictable (${tot.diag.verdict}), ` +
    `lets seven models compete, clusters your stores and answers questions in plain English.`;
  $('#story').innerHTML = D.insights.map(i => `<div class="card ${i.tone}"><div class="t">${i.tag}</div><h4>${i.title}</h4><p>${i.body}</p></div>`).join('');
  $('#foot').innerHTML = `source<br>${M.source}<br>built ${M.generated}`;
  $('#ft').textContent = `Meridian · built ${M.generated} from ${M.source} · ${num(M.rows)} rows · Unlox Major Project: Retail Analytics & AI-Powered Sales Forecasting System`;
}

/* ---------- Ask Meridian: tiny natural-language engine over the monthly cube ---------- */
const CHIPS = ['best store in Q4 2024 by revenue', 'revenue of Fashion in 2023', 'which category sells most units?', 'how much discount did we give in Mumbai?',
  'worst month by revenue', 'returning vs new customers', 'forecast for Electronics', 'average ticket by store'];
function ask(qs) {
  const q = qs.toLowerCase().trim(), host = $('#answer');
  if (!q) { host.innerHTML = ''; return; }
  const f = { year: 0, quarter: 0, month: 0, store: -1, cat: -1, sub: -1, cust: -1 };
  let m = q.match(/\b(2023|2024)\b/); if (m) f.year = +m[1];
  m = q.match(/\bq([1-4])\b/); if (m) f.quarter = +m[1];
  m = q.match(/\b(january|february|march|april|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec)\b/) || q.match(/\b(?:in|of|during|for)\s+(may)\b/);
  if (m) f.month = MON.findIndex(x => x.toLowerCase() === m[1].slice(0, 3)) + 1;
  M.stores.forEach((s, i) => { if (q.includes(s.id.toLowerCase().replace('_', '')) || q.includes(s.id.toLowerCase()) || q.includes(s.city.toLowerCase())) f.store = i; });
  [['electronic', 0], ['fashion', 1], ['grocer', 2], ['appliance', 3], ['sport', 4]].forEach(([w, i]) => { if (q.includes(w) && M.cats[i]) f.cat = i; });
  M.subs.forEach((s, i) => { const w = s.name.toLowerCase().replace(/s$/, ''); if (q.includes(w) && !(w === 'household' && f.cat >= 0)) f.sub = i; });
  const cmpCust = /\bnew\b/.test(q) && /returning|repeat|loyal/.test(q) && /vs|versus|\bor\b|\band\b|compare/.test(q);
  if (cmpCust) f.cust = -1; else if (/new (customer|shopper|buyer)/.test(q)) f.cust = 0; else if (/returning (customer|shopper|buyer)|repeat|loyal/.test(q)) f.cust = 1;
  const metric = /\b(unit|units|quantity|pieces)\b/.test(q) ? 'units' : /transaction|order|bills?|footfall|how many sales/.test(q) ? 'n' : /discount/.test(q) ? 'disc' :
    /ticket|basket|average|avg/.test(q) ? 'ticket' : /gross/.test(q) ? 'sales' : 'rev';
  const asc = /worst|lowest|least|bottom|weakest|smallest/.test(q);
  const mname = { rev: 'Net revenue', units: 'Units sold', n: 'Transactions', disc: 'Discount given', ticket: 'Average ticket', sales: 'Gross sales' }[metric];
  const fmt = v => metric === 'units' || metric === 'n' ? num(v) : metric === 'ticket' ? lakh(v) : cr(v);

  if (/forecast|predict|expect|next|projection|outlook|will we/.test(q)) {
    const key = f.store >= 0 ? 'store:' + M.stores[f.store].id : f.cat >= 0 ? 'cat:' + M.cats[f.cat] : 'TOTAL', F = D.forecast[key];
    host.innerHTML = `<div class="ans"><div class="big">${F.months.slice(0, 3).map(x => `${x.month}: ${cr(x.point)}`).join(' · ')}</div>
      <div class="note">${key === 'TOTAL' ? 'Total' : key.split(':')[1]} · champion <b>${F.champion_label}</b> · 80% range for ${F.months[0].month}: ${cr(F.months[0].lo80)} – ${cr(F.months[0].hi80)} · forecastability ${F.diag.score}/100 (${F.diag.verdict})</div></div>`;
    return;
  }
  const grp = /subcategor|which product|best product|top product/.test(q) ? 'sub' : /(by|per|each|which|best|top|worst|every) (store|city)|stores|cities/.test(q) && f.store < 0 ? 'store' :
    /categor/.test(q) && f.cat < 0 ? 'cat' : /quarter/.test(q) && !f.quarter ? 'quarter' : /(which|best|worst|by|each) month|months/.test(q) && !f.month ? 'month' :
    cmpCust || /customer type/.test(q) ? 'cust' : /discount (level|tier)|by discount/.test(q) ? 'disc' : '';
  const c = D.monthly, G = {}, tot = { rev: 0, sales: 0, units: 0, n: 0 };
  for (let i = 0; i < c.m.length; i++) {
    const mi = c.m[i], yr = MY[mi], mm = MMn[mi], su = c.u[i], st = c.s[i];
    if ((f.year && yr !== f.year) || (f.month && mm !== f.month) || (f.quarter && Math.ceil(mm / 3) !== f.quarter) || (f.store >= 0 && st !== f.store) ||
        (f.cat >= 0 && SC[su] !== f.cat) || (f.sub >= 0 && su !== f.sub) || (f.cust >= 0 && c.k[i] !== f.cust)) continue;
    ['rev', 'sales', 'units', 'n'].forEach(k => tot[k] += c[k][i]);
    if (!grp) continue;
    const key = grp === 'store' ? st : grp === 'cat' ? SC[su] : grp === 'sub' ? su : grp === 'month' ? mi : grp === 'quarter' ? yr * 10 + Math.ceil(mm / 3) : grp === 'cust' ? c.k[i] : c.x[i];
    const g = G[key] || (G[key] = { rev: 0, sales: 0, units: 0, n: 0 }); ['rev', 'sales', 'units', 'n'].forEach(k => g[k] += c[k][i]);
  }
  const val = o => metric === 'disc' ? o.sales - o.rev : metric === 'ticket' ? (o.n ? o.rev / o.n : 0) : o[metric];
  const desc = [f.quarter ? 'Q' + f.quarter : '', f.month ? MON[f.month - 1] : '', f.year || '', f.store >= 0 ? M.stores[f.store].city : '', f.cat >= 0 ? M.cats[f.cat] : '',
    f.sub >= 0 ? M.subs[f.sub].name : '', f.cust === 0 ? 'new customers' : f.cust === 1 ? 'returning customers' : ''].filter(Boolean).join(' · ') || 'all data';
  if (!grp) {
    if (!tot.n) { host.innerHTML = `<div class="ans"><div class="big">No matching sales</div><div class="note">Try another combination.</div></div>`; return; }
    host.innerHTML = `<div class="ans"><div class="note">${mname} · ${desc}</div><div class="big">${fmt(val(tot))}</div><div class="note">${num(tot.n)} transactions · ${num(tot.units)} units · this slice is ${pc(tot.rev / D.kpi.revenue)} of all revenue</div></div>`;
    return;
  }
  const lab = k => grp === 'store' ? M.stores[k].id + ' ' + M.stores[k].city : grp === 'cat' ? M.cats[k] : grp === 'sub' ? M.subs[k].name : grp === 'month' ? MON[MMn[k] - 1] + ' ' + MY[k] :
    grp === 'quarter' ? 'Q' + (k % 10) + ' ' + Math.floor(k / 10) : grp === 'cust' ? (k ? 'Returning' : 'New') : (k * 5) + '% off';
  let rows = Object.keys(G).map(k => ({ k: +k, v: val(G[k]) })).sort((a, b) => asc ? a.v - b.v : b.v - a.v);
  const top = rows[0], mx = Math.max(...rows.map(r => r.v)) || 1;
  rows = rows.slice(0, 8);
  host.innerHTML = `<div class="ans"><div class="note">${mname} by ${{ store: 'store', cat: 'category', sub: 'subcategory', month: 'month', quarter: 'quarter', cust: 'customer type', disc: 'discount tier' }[grp]} · ${desc}</div><div class="big">${asc ? 'Lowest' : 'Top'}: ${lab(top.k)} — ${fmt(top.v)}</div></div>` +
    rows.map(r => `<div class="mb"><span>${lab(r.k)}</span><span><i style="width:${(r.v / mx * 100).toFixed(1)}%"></i></span><span>${fmt(r.v)}</span></div>`).join('');
}

/* ======================= 02 PULSE ======================= */
const P = { gran: 'week', metric: 'rev' };
function togs(host, opts, key, cb) {
  host.innerHTML = ''; opts.forEach(([v, l]) => {
    const b = document.createElement('button'); b.textContent = l; b.className = P[key] === v ? 'on' : '';
    b.onclick = () => { P[key] = v; togs(host, opts, key, cb); cb(); }; host.appendChild(b);
  });
}
const shortFmt = metric => metric === 'rev' ? v => { const x = v / 1e7; return (Math.abs(x % 1) < 1e-9 || Math.abs(x) >= 100 ? x.toFixed(0) : x.toFixed(1)) + ' Cr'; } : v => num(v);
function renderTime() {
  const [a, b] = range(), vals = dailySeries(P.metric), bk = bucket(vals, P.gran, a, b), f = shortFmt(P.metric);
  const layers = [{ type: 'area', y: bk.y, color: '#d6a0ae', name: { day: 'Day', week: 'Week', month: 'Month' }[P.gran], fmt: P.metric === 'rev' ? cr2 : num }];
  if (P.gran === 'day') {
    const r = []; for (let i = a; i <= b; i++) { let s = 0, c = 0; for (let j = Math.max(0, i - 27); j <= i; j++) { s += vals[j]; c++; } r.push(i - a >= 27 ? s / c : null); }
    layers.push({ type: 'line', y: r, color: '#9f1239', width: 2, name: '28-day average', fmt: P.metric === 'rev' ? cr2 : num });
  }
  tsChart($('#cTime'), { x: bk.x, layers, fmtY: f, xfmt: dt, xticks: monthTicks(bk.x, S.year ? 1 : 3), height: 300, zero: P.gran === 'month' });
}
function renderYoY() {
  const s = dailySeries('rev', true), m = { 2023: new Array(12).fill(0), 2024: new Array(12).fill(0) };
  for (let i = 0; i < N; i++) m[DY[i]][DM[i] - 1] += s[i];
  const x = [...Array(12).keys()].map(i => i + 1);
  tsChart($('#cYoY'), { x, layers: [{ type: 'line', y: m[2023], color: '#d6a0ae', name: '2023', fmt: cr, width: 2.2 }, { type: 'line', y: m[2024], color: '#9f1239', name: '2024', fmt: cr, width: 2.2 }],
    fmtY: v => (v / 1e7).toFixed(0), xfmt: v => MON[v - 1], xticks: x.map(v => ({ x: v, l: MON[v - 1][0] })), height: 230, ymin: 0, ml: 44 });
  const t3 = m[2023].reduce((p, c) => p + c, 0), t4 = m[2024].reduce((p, c) => p + c, 0);
  const d = m[2024].map((v, i) => v / m[2023][i] - 1), up = d.filter(v => v > 0).length;
  $('#yoyNote').innerHTML = `2024 vs 2023: <b>${pct(t4 / t3 - 1)}</b> overall · 2024 was ahead in <b>${up} of 12</b> months (values in ₹ Cr).`;
}
function renderSeason() {
  const [a, b] = range(), v = dailySeries('rev'), dow = new Array(7).fill(0), dn = new Array(7).fill(0), mo = new Array(12).fill(0), mn = new Array(12).fill(0);
  let tot = 0, cnt = 0;
  for (let i = a; i <= b; i++) { dow[DOW[i]] += v[i]; dn[DOW[i]]++; mo[DM[i] - 1] += v[i]; mn[DM[i] - 1]++; tot += v[i]; cnt++; }
  const avg = tot / (cnt || 1), dev = (s, n) => n ? (s / n / avg - 1) * 100 : 0, col = x => x >= 0 ? '#d6a0ae' : '#ff6b6b';
  const fm = x => (x >= 0 ? '+' : '') + x.toFixed(1) + '%', dd = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  barChart($('#cDow'), dd.map((l, i) => ({ l, v: dev(dow[i], dn[i]), c: col(dev(dow[i], dn[i])) })), { fmt: fm, height: 140, base: 0, min: -6, max: 6 });
  barChart($('#cMon'), MON.map((l, i) => ({ l: l[0], v: dev(mo[i], mn[i]), c: col(dev(mo[i], mn[i])), tt: l })), { fmt: fm, height: 140, base: 0, min: -12, max: 12, tfmt: fm });
  const dg = D.forecast.TOTAL.diag;
  $('#seasNote').innerHTML = `Weekday effect: <b>${pv(dg.weekday_p)}</b> · month effect: <b>${pv(dg.month_p)}</b> (tests on total network revenue). Bars wobbling within a few percent are what randomness looks like — no real seasonality here.`;
}
const lerp = (a, b, t) => a + (b - a) * t, hex = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
function mix2(c1, c2, t) { const A = hex(c1), B = hex(c2); return `rgb(${A.map((v, i) => Math.round(lerp(v, B[i], t))).join(',')})`; }
function renderCal() {
  const host = $('#cCal'); host.innerHTML = ''; const v = dailySeries('rev'), years = S.year ? [S.year] : [2023, 2024], cs = 11, gp = 2, stp = cs + gp, W = 53 * stp + 36, H = years.length * (7 * stp + 34);
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%' }, host);
  years.forEach((yr, yi) => {
    const idx = []; for (let i = 0; i < N; i++) if (DY[i] === yr) idx.push(i);
    const sorted = idx.map(i => v[i]).sort((p, q) => p - q), med = sorted[sorted.length >> 1] || 1, off0 = DOW[idx[0]], y0 = yi * (7 * stp + 34) + 20;
    el('text', { x: 0, y: y0 - 8, class: 'lbl' }, svg, String(yr));
    idx.forEach((i, k) => {
      const col = Math.floor((k + off0) / 7), row = DOW[i], t = Math.max(-1, Math.min(1, (v[i] / med - 1) / 0.35));
      const r = el('rect', { x: 36 + col * stp, y: y0 + row * stp, width: cs, height: cs, rx: 2, fill: t >= 0 ? mix2('#24101a', '#9f1239', t) : mix2('#24101a', '#d6a0ae', -t) }, svg);
      r.addEventListener('mousemove', ev => showTip(ev, `<b>${dt(T[i])}</b><br>${cr2(v[i])}<br>${(v[i] / med * 100 - 100).toFixed(0)}% vs median day`)); r.addEventListener('mouseleave', hideTip);
      if (DM[i] !== (DM[i - 1] || 0) && DY[i - 1] === yr || k === 0) el('text', { x: 36 + col * stp, y: y0 - 8, class: 'ax' }, svg, MON[DM[i] - 1]);
    });
    ['M', 'W', 'F'].forEach((d, j) => el('text', { x: 20, y: y0 + [0, 2, 4][j] * stp + 9, class: 'ax' }, svg, d));
  });
}

/* ======================= 03 MIX ======================= */
function okM(i) { const c = D.monthly; return (!S.year || MY[c.m[i]] === S.year) && (!S.region || SR[c.s[i]] === S.region) && (S.cat < 0 || SC[c.u[i]] === S.cat); }
function renderSun() {
  const host = $('#cSun'); host.innerHTML = ''; const c = D.monthly, sub = new Array(M.subs.length).fill(0), cust = [0, 0], cn = [0, 0];
  for (let i = 0; i < c.m.length; i++) if (okM(i)) { sub[c.u[i]] += c.rev[i]; cust[c.k[i]] += c.rev[i]; cn[c.k[i]] += c.n[i]; }
  const cat = M.cats.map((_, ci) => M.subs.reduce((s, x, i) => s + (x.cat === ci ? sub[i] : 0), 0)), tot = cat.reduce((p, q) => p + q, 0) || 1;
  const W = Math.min(host.clientWidth || 460, 520), cx = W / 2, cy = W / 2, svg = el('svg', { viewBox: `0 0 ${W} ${W}`, width: W, height: W }, host);
  let a0 = 0;
  M.cats.forEach((cn_, ci) => {
    if (!cat[ci]) return; const a1 = a0 + cat[ci] / tot * Math.PI * 2;
    const p = el('path', { d: arc(cx, cy, W * .2, W * .31, a0, a1), fill: PAL[ci], opacity: .95, stroke: '#10070b', 'stroke-width': 2 }, svg);
    p.addEventListener('mousemove', ev => showTip(ev, `<b>${cn_}</b><br>${cr(cat[ci])} · ${pc(cat[ci] / tot)}`)); p.addEventListener('mouseleave', hideTip);
    const mid = (a0 + a1) / 2; if (a1 - a0 > .5) el('text', { x: cx + W * .255 * Math.sin(mid), y: cy - W * .255 * Math.cos(mid) + 4, 'text-anchor': 'middle', class: 'lbl', style: 'fill:#10070b;font-weight:600' }, svg, cn_.split(' ')[0]);
    let s0 = a0; M.subs.forEach((sb, si) => {
      if (sb.cat !== ci || !sub[si]) return; const s1 = s0 + sub[si] / tot * Math.PI * 2;
      const q = el('path', { d: arc(cx, cy, W * .32, W * .45, s0, s1), fill: PAL[ci], opacity: .5 + .1 * (si % 3), stroke: '#10070b', 'stroke-width': 1.5 }, svg);
      q.addEventListener('mousemove', ev => showTip(ev, `<b>${sb.name}</b> · ${cn_}<br>${cr(sub[si])} · ${pc(sub[si] / tot)}`)); q.addEventListener('mouseleave', hideTip);
      const md = (s0 + s1) / 2; if (s1 - s0 > .22) el('text', { x: cx + W * .385 * Math.sin(md), y: cy - W * .385 * Math.cos(md) + 3, 'text-anchor': 'middle', style: 'fill:#10070b;font:600 9px Inter,sans-serif' }, svg, sb.name.length > 9 ? sb.name.slice(0, 8) + '…' : sb.name);
      s0 = s1;
    }); a0 = a1;
  });
  el('text', { x: cx, y: cy - 2, 'text-anchor': 'middle', style: 'fill:#ebe8e1;font:400 22px Fraunces,Georgia,serif' }, svg, cr(tot));
  el('text', { x: cx, y: cy + 16, 'text-anchor': 'middle', class: 'ax' }, svg, 'net revenue');
  // customers, payments, promo
  const rows = [], add = (h, arr) => { rows.push(`<h3 style="margin-top:14px">${h}</h3>`); const t = arr.reduce((p, q) => p + q.v, 0) || 1; arr.forEach(r => rows.push(`<div class="mb"><span>${r.l}</span><span><i style="width:${(r.v / t * 100).toFixed(1)}%"></i></span><span>${pc(r.v / t)} · ${r.s}</span></div>`)); };
  add('Customer type (filtered)', [{ l: 'New', v: cust[0], s: cn[0] ? lakh(cust[0] / cn[0]) : '–' }, { l: 'Returning', v: cust[1], s: cn[1] ? lakh(cust[1] / cn[1]) : '–' }]);
  add('Payment mode (all data)', D.mix.payment.map(x => ({ l: x.k, v: x.rev, s: lakh(x.ticket) })));
  add('Promotion applied (all data)', D.mix.promo.map(x => ({ l: x.k === 'Yes' ? 'On promotion' : 'No promotion', v: x.rev, s: lakh(x.ticket) })));
  add('Region (all data)', D.mix.region.map(x => ({ l: x.k, v: x.rev, s: lakh(x.ticket) })));
  $('#cMixBars').innerHTML = rows.join('') + '<div class="note">Right-hand value = average ticket.</div>';
}
function renderPareto() {
  const p = D.pareto, y = [0, ...p.curve], x = y.map((_, i) => i);
  tsChart($('#cPar'), { x, layers: [{ type: 'line', y: x.map(v => v / 100), color: '#5d6578', dash: '4 4', name: 'Perfect equality', fmt: v => pc(v, 0) }, { type: 'area', y, color: '#9f1239', name: 'Cumulative revenue', fmt: v => pc(v, 0) }],
    fmtY: v => pc(v, 0), xfmt: v => v + '% of SKUs', xticks: [0, 20, 40, 60, 80, 100].map(v => ({ x: v, l: v + '%' })), height: 250, ymin: 0, ymax: 1, ml: 44 });
  $('#parNote').innerHTML = `Top 20% of ${p.n} SKU codes = <b>${pc(p.top20_share, 0)}</b> of revenue (a typical retail 80/20 would sit near 80%). Gini <b>${p.gini.toFixed(2)}</b>. ABC classes: A ${p.abc.A} · B ${p.abc.B} · C ${p.abc.C} — the curve hugs the diagonal, so SKU pruning is not a lever here.`;
  const b = D.mix.brands.filter(x => S.cat < 0 || M.cats[S.cat] === x.cat).slice(0, 12), mx = b[0].rev;
  $('#cBrand').innerHTML = b.map(x => `<div class="mb"><span>${x.k}</span><span><i style="width:${(x.rev / mx * 100).toFixed(1)}%;background:${PAL[M.cats.indexOf(x.cat)]}"></i></span><span>${cr(x.rev)}</span></div>`).join('') + '<div class="note">All dates, colour = category.</div>';
}

/* ======================= 04 STORES ======================= */
const INDIA = [[74, 34.5], [75.5, 36.8], [77.8, 35.5], [79, 33], [78.8, 31], [80.2, 30.2], [81, 30.2], [80.6, 28.8], [84, 27.3], [88.1, 26.5], [88.9, 27.9], [92, 27.8], [96, 28.3], [97.3, 28], [95.5, 26], [94.5, 24], [93.3, 22.5], [92.3, 21.9], [92.3, 23.7], [91.2, 24], [89, 22], [87, 21.5], [86.9, 20.2], [85, 19.3], [82.3, 16.7], [80.3, 15.5], [80.2, 13.4], [79.8, 10.3], [78.2, 8.9], [77.5, 8.1], [76.3, 9.6], [75, 12], [74, 14.8], [73, 17.5], [72.8, 19.5], [72.7, 21.5], [70.2, 20.8], [69, 22.3], [68.6, 23.5], [70, 24.2], [71, 24.4], [70.5, 26], [69.5, 27], [71, 28], [73, 29.5], [74.5, 31], [74.3, 32.5]];
let selStore = 0;
function renderMap() {
  const host = $('#cMap'); host.innerHTML = ''; const px = lo => (lo - 66) * 14, py = la => (38 - la) * 14, W = 476, H = 448, seg = D.segments;
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%' }, host);
  el('path', { d: 'M' + INDIA.map(p => px(p[0]).toFixed(1) + ' ' + py(p[1]).toFixed(1)).join('L') + 'Z', fill: '#1a0b12', stroke: '#2e3547', 'stroke-dasharray': '2 4' }, svg);
  for (let i = 0; i < 70; i++) el('circle', { cx: (Math.sin(i * 12.9898) * 43758.5453 % 1 + 1) % 1 * W, cy: (Math.sin(i * 78.233) * 12543.531 % 1 + 1) % 1 * H, r: .9, fill: '#2e3547' }, svg);
  const revs = seg.stores.map(s => s.revenue), lo = Math.min(...revs), hi = Math.max(...revs);
  for (let c = 0; c < seg.k; c++) {
    const g = seg.stores.filter(s => s.cluster === c).sort((a, b) => a.lon - b.lon);
    for (let i = 1; i < g.length; i++) el('line', { x1: px(g[i - 1].lon), y1: py(g[i - 1].lat), x2: px(g[i].lon), y2: py(g[i].lat), stroke: CL[c], 'stroke-width': 1, opacity: .55, 'stroke-dasharray': '4 3' }, svg);
  }
  seg.stores.forEach((s, i) => {
    const r = 9 + (s.revenue - lo) / ((hi - lo) || 1) * 8, g = el('g', { style: 'cursor:pointer' }, svg);
    el('circle', { cx: px(s.lon), cy: py(s.lat), r: r + 8, fill: CL[s.cluster], opacity: .12 }, g);
    el('circle', { cx: px(s.lon), cy: py(s.lat), r, fill: CL[s.cluster], stroke: i === selStore ? '#fff' : '#10070b', 'stroke-width': i === selStore ? 2.5 : 2 }, g);
    el('text', { x: px(s.lon), y: py(s.lat) + 4, 'text-anchor': 'middle', style: 'fill:#10070b;font:600 10px JetBrains Mono,monospace' }, g, s.id.slice(-1));
    el('text', { x: px(s.lon) + r + 6, y: py(s.lat) + 4, class: 'lbl' }, g, s.city);
    g.addEventListener('click', () => { selStore = i; renderStores(); });
    g.addEventListener('mousemove', ev => showTip(ev, `<b>${s.id} · ${s.city}</b><br>${s.archetype}<br>health ${s.health.toFixed(0)}/100 · ${cr(s.revenue)}`)); g.addEventListener('mouseleave', hideTip);
  });
  $('#legend').innerHTML = Object.entries(seg.archetypes).map(([k, a]) => `<span style="color:${CL[k]}">●</span> ${a.name} <span style="color:var(--dim)">(${a.size}, driven by ${a.driver.toLowerCase()})</span>`).join(' &nbsp; ') + `<br>Star size = revenue · silhouette ${seg.silhouette.toFixed(2)} · k = ${seg.k} chosen automatically`;
  $('#segNote').innerHTML = `<b>Read with care:</b> stores differ by only ${seg.spread_pct.toFixed(1)}% in revenue and basket value is not significantly different across stores (${pv(seg.anova_p_ticket)}). Segments rank relative behaviour; they do not signal a problem store.`;
}
function renderRadar() {
  const host = $('#cRad'); host.innerHTML = ''; const s = D.segments.stores[selStore], F = D.segments.features, W = 300, H = 270, cx = 150, cy = 135, R = 88, n = F.length;
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%' }, host), ang = i => i / n * Math.PI * 2 - Math.PI / 2, pt = (i, r) => [cx + r * Math.cos(ang(i)), cy + r * Math.sin(ang(i))];
  [.5, 1].forEach(f => el('polygon', { points: F.map((_, i) => pt(i, R * f).join(',')).join(' '), fill: 'none', stroke: f === .5 ? '#5d6578' : '#232938', 'stroke-dasharray': f === .5 ? '3 3' : '' }, svg));
  F.forEach((k, i) => { const [x, y] = pt(i, R + 12); el('line', { x1: cx, y1: cy, x2: pt(i, R)[0], y2: pt(i, R)[1], stroke: '#232938' }, svg); el('text', { x, y: y + 3, 'text-anchor': Math.abs(x - cx) < 8 ? 'middle' : x > cx ? 'start' : 'end', style: 'font:9px Inter,sans-serif' }, svg, D.segments.feature_labels[k]); });
  const pts = F.map((k, i) => pt(i, R * (Math.max(-2.5, Math.min(2.5, s.z[k])) + 2.5) / 5 ));
  el('polygon', { points: pts.map(p => p.join(',')).join(' '), fill: CL[s.cluster], 'fill-opacity': .25, stroke: CL[s.cluster], 'stroke-width': 2 }, svg);
  pts.forEach(p => el('circle', { cx: p[0], cy: p[1], r: 2.6, fill: CL[s.cluster] }, svg));
  $('#radT').textContent = `${s.id} · ${s.city} (dashed ring = network average)`;
}
function renderStores() {
  const c = D.daily, rev = new Array(M.stores.length).fill(0);
  for (let i = 0; i < c.d.length; i++) if ((!S.year || DY[c.d[i]] === S.year) && (S.cat < 0 || c.c[i] === S.cat)) rev[c.s[i]] += c.rev[i];
  const live = rev.filter((v, i) => !S.region || SR[i] === S.region), avg = live.reduce((p, q) => p + q, 0) / (live.length || 1), seg = D.segments;
  const order = seg.stores.map((s, i) => i).sort((a, b) => seg.stores[b].health - seg.stores[a].health);
  $('#tStores').innerHTML = `<tr><th>Store</th><th>City</th><th class="n">Revenue</th><th class="n">vs avg</th><th class="n">Health</th><th>Archetype</th></tr>` + order.map(i => {
    const s = seg.stores[i], off = S.region && s.region !== S.region;
    return `<tr class="clk ${i === selStore ? 'sel' : ''} ${off ? 'dim' : ''}" data-i="${i}"><td>${s.id}</td><td>${s.city}</td><td class="n">${cr(rev[i])}</td><td class="n ${rev[i] >= avg ? 'up' : 'dn'}">${pct(rev[i] / avg - 1)}</td><td class="n">${s.health.toFixed(0)}</td><td><span style="color:${CL[s.cluster]}">●</span> ${s.archetype}</td></tr>`;
  }).join('');
  document.querySelectorAll('#tStores tr.clk').forEach(r => r.onclick = () => { selStore = +r.dataset.i; renderStores(); });
  const s = seg.stores[selStore], a = seg.archetypes[s.cluster];
  $('#storeInfo').innerHTML = `<h3>${s.id} · ${s.city} · ${s.region}</h3><div style="font:400 26px var(--serif);color:${CL[s.cluster]}">${s.archetype}</div>
    <div class="note">Cluster driver: ${a.driver} (z ${a.z.toFixed(1)}) · health <b>${s.health.toFixed(0)}/100</b></div>
    <table style="margin-top:10px">${[['Ticket', lakh(s.ticket)], ['Units / basket', s.units_per_txn.toFixed(1)], ['Avg discount', s.avg_discount.toFixed(1) + '%'], ['Returning share', pc(s.returning_share)], ['YoY growth', pct(s.growth)], ['Rating', s.rating.toFixed(2)], ['Volatility (CV)', pc(s.volatility)], ['Avg stock on hand', num(s.stock_cover)]].map(r => `<tr><td>${r[0]}</td><td class="n">${r[1]}</td></tr>`).join('')}</table>`;
  renderMap(); renderRadar();
}

/* ======================= 05 FORECAST ======================= */
function renderForecast() {
  const key = $('#fSeries').value, F = D.forecast[key], ch = F.board[0], base = F.board.find(b => b.model === 'mean_all'), dg = F.diag;
  const six = F.months.slice(0, 6).reduce((p, q) => p + q.point, 0);
  $('#fTiles').innerHTML = [['Champion', F.champion_label, ''], ['Forecastability', dg.score + ' / 100', dg.verdict], ['Backtest MAPE', ch.mape.toFixed(1) + '%', 'daily, 30-day horizon'],
    ['Skill vs long-run mean', pct(ch.skill), 'fold win-rate ' + pc(ch.win_rate, 0)], ['Next 6 months', cr(six), 'point forecast']].map(t => `<div class="tile"><div class="l">${t[0]}</div><div class="v" style="${t[1].length > 16 ? 'font-size:17px;line-height:1.5' : ''}">${t[1]}</div><div class="note" style="margin:0">${t[2]}</div></div>`).join('');
  const H = F.history_tail, f = F.forecast, hx = H.date.map(Date.parse), fx = f.date.map(Date.parse), x = hx.concat(fx), nh = hx.length, nf = fx.length;
  const padH = a => a.concat(new Array(nf).fill(null)), padF = a => new Array(nh).fill(null).concat(a);
  const hist = padH(H.value), pt = padF(f.point); pt[nh - 1] = H.value[nh - 1];
  tsChart($('#cFan'), { x, split: fx[0], splitLabel: 'forecast →', xfmt: dt, fmtY: shortFmt('rev'), xticks: monthTicks(x, 1), height: 320, ml: 56, layers: [
    { type: 'band', y: padF(f.hi95), y0: padF(f.lo95), color: '#9f1239', opacity: .12 }, { type: 'band', y: padF(f.hi80), y0: padF(f.lo80), color: '#9f1239', opacity: .22 },
    { type: 'line', y: hist, color: '#d6a0ae', name: 'Actual', fmt: cr2, width: 1.4 }, { type: 'line', y: pt, color: '#9f1239', name: 'Forecast', fmt: cr2, width: 2.4 },
    { type: 'line', y: padF(f.lo80), y0: null, color: 'transparent', name: '80% low', fmt: cr2 }, { type: 'line', y: padF(f.hi80), color: 'transparent', name: '80% high', fmt: cr2 }] });
  const mx = Math.max(...F.board.map(b => b.mae));
  $('#cArena').innerHTML = F.board.map((b, i) => `<div class="row ${i === 0 ? 'ch' : ''}"><span>${i === 0 ? '★ ' : ''}${b.label}${b.model === 'mean_all' ? ' <small style="color:var(--dim)">(baseline)</small>' : ''}</span><span class="trk"><i style="width:${(b.mae / mx * 100).toFixed(1)}%"></i></span><span>${(b.mae / 1e7).toFixed(2)} Cr · ${pct(b.skill)}</span></div>`).join('');
  const beat = F.board.filter(b => b.model !== 'mean_all' && b.skill > 0.02).length;
  $('#arenaNote').innerHTML = `Metric: mean absolute error per day, then skill vs the long-run mean. <b>${beat}</b> of 6 challengers beat the baseline by more than 2%. ` +
    (beat === 0 ? 'No model finds structure worth chasing, so a flat level with honest bands is the defensible forecast.' : 'A challenger found real structure.');
  const B = F.backtest, bx = B.date.map(Date.parse), lay = [{ type: 'line', y: B.actual, color: '#d6a0ae', name: 'Actual', fmt: cr2, width: 1.1, opacity: .85 }, { type: 'line', y: B.pred, color: '#9f1239', name: F.champion_label, fmt: cr2, width: 2.2 }];
  if (F.champion !== 'mean_all') lay.push({ type: 'line', y: B.baseline, color: '#8d95a8', dash: '4 4', name: 'Long-run mean', fmt: cr2, width: 1.4 });
  tsChart($('#cBack'), { x: bx, layers: lay, fmtY: shortFmt('rev'), xfmt: dt, xticks: monthTicks(bx, 2), height: 250 });
  $('#tMonths').innerHTML = `<tr><th>Month</th><th class="n">Forecast</th><th class="n">80% range</th><th class="n">95% range</th><th class="n">Days</th></tr>` +
    F.months.map(m => `<tr><td>${m.month}</td><td class="n">${cr(m.point)}</td><td class="n">${cr(m.lo80)} – ${cr(m.hi80)}</td><td class="n">${cr(m.lo95)} – ${cr(m.hi95)}</td><td class="n">${m.days}</td></tr>`).join('');
}

/* ======================= 06 DISCOUNT LAB ======================= */
function renderLab() {
  const d = D.discount, lv = d.levels;
  barChart($('#cDisc'), lv.map((r, i) => ({ l: r.Discount_Percentage + '%', v: r.units, c: PAL[i] })), { fmt: v => v.toFixed(1), height: 210, min: 0, max: 30, tfmt: v => v.toFixed(2) + ' units per sale' });
  $('#discNote').innerHTML = `Basket size is flat from 0% to 20% off (ANOVA <b>${pv(d.p_units_anova)}</b>), transactions are evenly split across tiers (${pv(d.p_txn_chi2)}) and promoted sales are no bigger than unpromoted ones (${pv(d.p_promo)}). ` +
    `Estimated volume response: <b>${(d.lift_per_pp * 100).toFixed(2)}% per point</b> (95% CI ±${(d.lift_ci * 100).toFixed(2)}%).`;
  const sD = $('#sD'), sL = $('#sL'), d0 = d.leak_share * 100, G = d.gross / 2;
  const run = () => {
    const d1 = +sD.value, L = +sL.value; $('#oD').textContent = d1.toFixed(1) + '%'; $('#oL').textContent = (L >= 0 ? '+' : '') + L.toFixed(2) + '%';
    const mult = 1 + L / 100 * (d1 - d0), r0 = G * (1 - d0 / 100), r1 = G * mult * (1 - d1 / 100), dl = r1 - r0;
    const be = Math.abs(d1 - d0) < .01 ? null : ((1 - d0 / 100) / (1 - d1 / 100) - 1) / (d1 - d0) * 100;
    $('#simRes').innerHTML = [['Net revenue today', cr(r0), 'avg discount ' + d0.toFixed(1) + '%'], ['Scenario', cr(r1), 'volume ' + pct(mult - 1)], ['Change per year', (dl >= 0 ? '+' : '−') + cr(Math.abs(dl)), pct(dl / r0, 2)],
      ['Break-even response', be == null ? '–' : be.toFixed(2) + '% / pt', 'observed ' + (d.lift_per_pp * 100).toFixed(2) + '% ± ' + (d.lift_ci * 100).toFixed(2)]].map((t, i) =>
      `<div class="tile"><div class="l">${t[0]}</div><div class="v ${i === 2 ? (dl >= 0 ? 'up' : 'dn') : ''}">${t[1]}</div><div class="note" style="margin:0">${t[2]}</div></div>`).join('');
    $('#simNote').innerHTML = be == null ? 'Move the discount slider to simulate a policy change.' : d1 < d0 ?
      `Cutting to ${d1.toFixed(1)}% pays off unless volume falls by more than <b>${be.toFixed(2)}%</b> for every point removed. History shows ${(d.lift_per_pp * 100).toFixed(2)}% ± ${(d.lift_ci * 100).toFixed(2)}%.` :
      `Raising discounts to ${d1.toFixed(1)}% only pays off if each extra point lifts volume by more than <b>${be.toFixed(2)}%</b>. History shows ${(d.lift_per_pp * 100).toFixed(2)}% ± ${(d.lift_ci * 100).toFixed(2)}%.`;
  };
  sD.value = Math.round(d0 * 2) / 2; sL.value = Math.max(-2, Math.min(6, d.lift_per_pp * 100)); sD.oninput = run; sL.oninput = run; run();
}

/* ======================= 07 INTEGRITY ======================= */
function renderQuality() {
  $('#tQuality').innerHTML = `<tr><th>Check</th><th>Result</th><th>Detail</th></tr>` + D.quality.map(q => `<tr><td>${q.name}</td><td><span class="badge ${q.status}">${q.status.toUpperCase()}</span></td><td style="color:var(--mute)">${q.detail}</td></tr>`).join('');
}

/* ======================= wiring ======================= */
function seg(host, opts, key, cb) {
  host.innerHTML = ''; opts.forEach(([v, l]) => { const b = document.createElement('button'); b.textContent = l; if (S[key] === v) b.className = 'on';
    b.onclick = () => { S[key] = v; seg(host, opts, key, cb); cb(); }; host.appendChild(b); });
}
function renderFiltered() {
  const bits = [S.year || 'both years', S.region || 'all regions', S.cat >= 0 ? M.cats[S.cat] : 'all categories'];
  $('#scope').textContent = 'scope: ' + bits.join(' · ');
  renderKPIs(); renderTime(); renderYoY(); renderSeason(); renderCal(); renderSun(); renderPareto(); renderStores(); ask($('#q').value);
}
function renderAll() { renderFiltered(); renderForecast(); renderLab(); }
function init() {
  renderBrief(); renderQuality();
  seg($('#fYear'), [[0, 'All'], [2023, '2023'], [2024, '2024']], 'year', renderFiltered);
  seg($('#fRegion'), [['', 'All'], ...[...new Set(SR)].sort().map(r => [r, r])], 'region', renderFiltered);
  const fc = $('#fCat'); fc.innerHTML = `<option value="-1">All categories</option>` + M.cats.map((c, i) => `<option value="${i}">${c}</option>`).join(''); fc.onchange = () => { S.cat = +fc.value; renderFiltered(); };
  const fs = $('#fSeries'); fs.innerHTML = Object.keys(D.forecast).map(k => `<option value="${k}">${k === 'TOTAL' ? 'Total network' : k.startsWith('cat:') ? 'Category · ' + k.slice(4) : 'Store · ' + k.slice(6) + ' ' + M.stores.find(s => s.id === k.slice(6)).city}</option>`).join('');
  fs.onchange = renderForecast;
  togs($('#tgGran'), [['day', 'Daily'], ['week', 'Weekly'], ['month', 'Monthly']], 'gran', renderTime);
  togs($('#tgMetric'), [['rev', 'Revenue'], ['n', 'Transactions'], ['units', 'Units']], 'metric', renderTime);
  $('#chips').innerHTML = CHIPS.map(c => `<button class="chip">${c}</button>`).join('');
  document.querySelectorAll('.chip').forEach(b => b.onclick = () => { $('#q').value = b.textContent; ask(b.textContent); });
  $('#go').onclick = () => ask($('#q').value); $('#q').onkeydown = e => { if (e.key === 'Enter') ask($('#q').value); };
  renderAll();
  const links = document.querySelectorAll('.rail a');
  if (window.IntersectionObserver) {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) links.forEach(a => a.classList.toggle('on', a.getAttribute('href') === '#' + e.target.id)); }), { rootMargin: '-30% 0px -60% 0px' });
    document.querySelectorAll('main section').forEach(s => io.observe(s));
  }
  let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(renderAll, 200); });
}
init();
})();
