"""Store segmentation: behavioural features -> KMeans (k by silhouette) -> archetypes + health score."""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

from .config import CITY_GEO, SEED

FEATURES = ["revenue", "txns", "ticket", "units_per_txn", "avg_discount", "promo_rate",
            "returning_share", "growth", "volatility", "rating", "category_concentration"]
LABELS = {"revenue": "Revenue", "txns": "Traffic", "ticket": "Basket value", "units_per_txn": "Units / basket",
          "avg_discount": "Discount depth", "promo_rate": "Promo rate", "returning_share": "Loyalty",
          "growth": "YoY growth", "volatility": "Volatility", "rating": "Rating",
          "category_concentration": "Category focus"}
NAMES = {("revenue", 1): "Volume Engine", ("txns", 1): "Traffic Magnet", ("ticket", 1): "Premium Basket",
         ("units_per_txn", 1): "Bulk Buyers", ("avg_discount", 1): "Promo-Hungry", ("promo_rate", 1): "Promo-Led",
         ("returning_share", 1): "Loyalty Fortress", ("growth", 1): "Rising Star", ("volatility", 1): "Volatile",
         ("rating", 1): "Crowd Favourite", ("category_concentration", 1): "Specialist",
         ("revenue", -1): "Lighter Volume", ("txns", -1): "Quiet Street", ("ticket", -1): "Value Basket",
         ("units_per_txn", -1): "Small Baskets", ("avg_discount", -1): "Margin Guardian", ("promo_rate", -1): "Full-Price Faithful",
         ("returning_share", -1): "Acquisition Mode", ("growth", -1): "Cooling Down", ("volatility", -1): "Steady Eddie",
         ("rating", -1): "Softer Ratings", ("category_concentration", -1): "Generalist"}


def store_features(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for sid, g in df.groupby("Store_ID"):
        daily = g.groupby("Date").Revenue.sum()
        cat = g.groupby("Product_Category").Revenue.sum()
        y = g.groupby("Year").Revenue.sum()
        rows.append({
            "store": sid, "city": g.Store_Location.iat[0], "region": g.Region.iat[0],
            "revenue": g.Revenue.sum(), "txns": len(g), "ticket": g.Revenue.mean(),
            "units_per_txn": g.Units_Sold.mean(), "avg_discount": g.Discount_Percentage.mean(),
            "promo_rate": (g.Promotion_Applied == "Yes").mean(), "returning_share": (g.Customer_Type == "Returning").mean(),
            "growth": y.get(2024, np.nan) / y.get(2023, np.nan) - 1, "volatility": daily.std() / daily.mean(),
            "rating": g.Store_Rating.mean(), "category_concentration": (cat / cat.sum()).max(),
            "stock_cover": g.Stock_On_Hand.mean(), "lat": CITY_GEO[g.Store_Location.iat[0]][0],
            "lon": CITY_GEO[g.Store_Location.iat[0]][1],
        })
    return pd.DataFrame(rows).set_index("store")


def segment(df: pd.DataFrame) -> dict:
    f = store_features(df)
    X = StandardScaler().fit_transform(f[FEATURES])
    best = max(range(2, 5), key=lambda k: silhouette_score(X, KMeans(k, n_init=20, random_state=SEED).fit_predict(X)))
    km = KMeans(best, n_init=50, random_state=SEED).fit(X)
    sil = float(silhouette_score(X, km.labels_))
    f["cluster"] = km.labels_
    pcs = PCA(2, random_state=SEED).fit_transform(X)
    f["pc1"], f["pc2"] = pcs[:, 0], pcs[:, 1]
    Z = pd.DataFrame(X, index=f.index, columns=FEATURES)
    arche = {}
    for c in range(best):
        z = Z[f.cluster == c].mean()
        top = z.abs().idxmax()
        arche[c] = {"name": NAMES[(top, 1 if z[top] > 0 else -1)], "driver": LABELS[top], "z": float(z[top]), "size": int((f.cluster == c).sum())}
    seen = {}
    for c, a in arche.items():            # make names unique
        seen[a["name"]] = seen.get(a["name"], 0) + 1
        if seen[a["name"]] > 1:
            a["name"] += f" {seen[a['name']]}"
    # health score = mean percentile rank (higher is better) across 6 KPIs
    good = pd.DataFrame({"revenue": f.revenue.rank(pct=True), "ticket": f.ticket.rank(pct=True), "growth": f.growth.rank(pct=True),
                         "rating": f.rating.rank(pct=True), "discount": 1 - f.avg_discount.rank(pct=True),
                         "stability": 1 - f.volatility.rank(pct=True)})
    f["health"] = (good.mean(axis=1) * 100).round(0)
    rev_by_store = [g.Revenue.values for _, g in df.groupby("Store_ID")]
    p = float(stats.f_oneway(*rev_by_store).pvalue)
    tot = f.revenue
    z_all = {c: Z.loc[f.cluster == c].mean().round(2).to_dict() for c in range(best)}
    stores = []
    for sid, r in f.iterrows():
        stores.append({"id": sid, "city": r.city, "region": r.region, "lat": r.lat, "lon": r.lon,
                       "cluster": int(r.cluster), "archetype": arche[int(r.cluster)]["name"], "health": float(r.health),
                       "pc1": float(r.pc1), "pc2": float(r.pc2), "stock_cover": float(r.stock_cover),
                       **{k: float(r[k]) for k in FEATURES}, "z": {k: float(Z.loc[sid, k]) for k in FEATURES}})
    return {"k": int(best), "silhouette": sil, "archetypes": {str(k): v for k, v in arche.items()}, "stores": stores,
            "feature_labels": LABELS, "features": FEATURES, "anova_p_ticket": p,
            "spread_pct": float((tot.max() - tot.min()) / tot.mean() * 100), "cluster_z": {str(k): v for k, v in z_all.items()}}, f
