"""Project-wide constants."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "outputs"
WEB_DIR = ROOT / "web"
DEFAULT_DATA = DATA_DIR / "Retail_Sales_Data_Unlox.csv"

# lat / lon of each store city (used for the constellation map)
CITY_GEO = {
    "Delhi": (28.61, 77.21), "Mumbai": (19.08, 72.88), "Bangalore": (12.97, 77.59),
    "Chennai": (13.08, 80.27), "Kolkata": (22.57, 88.36), "Hyderabad": (17.39, 78.48),
    "Pune": (18.52, 73.86), "Ahmedabad": (23.02, 72.57),
}
HORIZON_DAYS = 181          # forecast horizon (Jan-Jun 2025)
BACKTEST_H = 30             # each rolling-origin fold forecasts 30 days
BACKTEST_FOLDS = 11
SEED = 42
