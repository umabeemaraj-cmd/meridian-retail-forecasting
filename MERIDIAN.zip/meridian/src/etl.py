"""Load, validate and enrich the raw retail data."""
import numpy as np
import pandas as pd
from pathlib import Path


def _parse_dates(s: pd.Series) -> pd.Series:
    """Handles ISO (csv) and dd-mm-yyyy (xlsx) strings in the same column."""
    s = s.astype(str).str.strip()
    iso = pd.to_datetime(s.str[:10], format="%Y-%m-%d", errors="coerce")
    dmy = pd.to_datetime(s.str[:10], format="%d-%m-%Y", errors="coerce")
    return iso.fillna(dmy)


def load(path) -> pd.DataFrame:
    p = Path(path)
    df = pd.read_excel(p) if p.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(p)
    df["Date"] = _parse_dates(df["Date"])
    if df["Date"].isna().any():
        raise ValueError("Unparseable dates found in the Date column")
    return df


def enrich(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["Discount_Amount"] = df["Total_Sales"] - df["Revenue"]
    df["Year"] = df["Date"].dt.year
    df["Month"] = df["Date"].dt.month
    df["Quarter"] = df["Date"].dt.quarter
    df["DOW"] = df["Date"].dt.dayofweek
    df["YM"] = df["Date"].dt.to_period("M").astype(str)
    return df


def validate(df: pd.DataFrame) -> list:
    """Return a list of data-integrity checks: {name, status, detail}."""
    chk = []

    def add(name, ok, detail, warn=False):
        chk.append({"name": name, "status": "pass" if ok else ("warn" if warn else "fail"), "detail": detail})

    add("Row count", True, f"{len(df):,} rows x {df.shape[1]} columns")
    nulls = int(df.isna().sum().sum())
    add("Missing values", nulls == 0, f"{nulls} missing cells")
    dups = int(df.duplicated().sum())
    add("Duplicate rows", dups == 0, f"{dups} exact duplicates")
    span = pd.date_range(df.Date.min(), df.Date.max())
    miss = len(span.difference(pd.DatetimeIndex(df.Date.unique())))
    add("Calendar coverage", miss == 0,
        f"{df.Date.min():%d %b %Y} to {df.Date.max():%d %b %Y}, {len(span)} days, {miss} days without sales")
    e1 = float((df.Total_Sales - df.Unit_Price * df.Units_Sold).abs().max())
    add("Total_Sales = Unit_Price x Units_Sold", e1 < 0.01, f"max abs difference {e1:.2e}")
    e2 = float((df.Revenue - df.Total_Sales * (1 - df.Discount_Percentage / 100)).abs().max())
    add("Revenue = Total_Sales x (1 - Discount%)", e2 < 0.01, f"max abs difference {e2:.2e}")
    one = df.groupby("Store_ID")[["Store_Location", "Region"]].nunique().max().max() == 1
    add("Store -> City -> Region is 1:1", bool(one), f"{df.Store_ID.nunique()} stores, {df.Region.nunique()} regions")
    over = float((df.Units_Sold > df.Stock_On_Hand).mean())
    add("Units sold never exceed stock on hand", over == 0, f"{over:.2%} rows violate")
    pc = df.groupby("Product_ID").Product_Category.nunique().max()
    add("Product_ID maps to one category", pc == 1,
        f"each Product_ID appears under up to {pc} categories and {df.groupby('Product_ID').Brand.nunique().max()} brands - "
        "so it is treated as a SKU code, and merchandising is analysed at Brand / Subcategory level", warn=True)
    bc = df.groupby("Brand").Product_Category.nunique().max()
    add("Brand -> Category is unique", bc == 1, f"max categories per brand = {bc}")
    add("Rating range", bool(df.Store_Rating.between(1, 5).all()), f"{df.Store_Rating.min()} to {df.Store_Rating.max()}")
    q1, q3 = df.Revenue.quantile([.25, .75])
    out = float((df.Revenue > q3 + 3 * (q3 - q1)).mean())
    add("Extreme revenue outliers (3xIQR)", out < 0.01, f"{out:.2%} of rows", warn=True)
    hm = sorted(int(m) for m in df.loc[df.Holiday_Flag == 1, "Date"].dt.month.unique())
    add("Holiday_Flag coverage", len(hm) >= 6,
        f"flag only appears in months {hm}; holiday uplift cannot be learned for other months", warn=True)
    return chk
